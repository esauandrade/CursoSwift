//Juego de Memoria

import UIKit

var numeros = 0...100
var five = 5
var par = 2
var impar = 1

for num in numeros{
    print("#", num)
    if num == five{
        print("Bingo!!!")
        five = five + 5
    }
    ;if num == par{
        print("Par!!!")
        par = par + 2
    }
    ;if num == impar{
        print("Impar!!!")
        impar = impar + 2
    }
    ;if num >= 30 && num <= 40{
        print("Viva Swift!!!")
    }
}